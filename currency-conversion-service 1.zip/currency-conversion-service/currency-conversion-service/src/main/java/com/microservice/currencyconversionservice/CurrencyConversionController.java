package com.microservice.currencyconversionservice;

import java.math.BigDecimal;
import java.util.HashMap;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@Configuration
 class WebConfig {

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder.build();
    }
}

@RestController
public class CurrencyConversionController {

	private CurrencyExchangeProxy currencyExchangeProxy;
	
private RestTemplate restTemplate;


	public CurrencyConversionController(CurrencyExchangeProxy currencyExchangeProxy,RestTemplate restTemplate) {
		super();
		this.currencyExchangeProxy = currencyExchangeProxy;
		this.restTemplate = restTemplate;
	}

	@GetMapping("/currency-conversion/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion calculateCurrencyConvery(@PathVariable String from, @PathVariable String to,
			@PathVariable BigDecimal quantity) {
		HashMap<String, String> uriVariable = new HashMap<>();
		uriVariable.put("from", from);
		uriVariable.put("to", to);

		ResponseEntity<CurrencyConversion> response = restTemplate.getForEntity(
				"http://localhost:8000/currency-exchange/from/{from}/to/{to}", CurrencyConversion.class, uriVariable);
		CurrencyConversion body = response.getBody();
		return new CurrencyConversion(body.getId(), from, to, quantity.multiply(body.getConversionMultiple()),
				body.getConversionMultiple(), body.getTotalCalculatedAmt(), body.getEnvironment());

	}

	@GetMapping("/currency-conversion-feign/from/{from}/to/{to}/quantity/{quantity}")
	public CurrencyConversion calculateCurrencyConveryFeign(@PathVariable String from, @PathVariable String to,
			@PathVariable BigDecimal quantity) {
		CurrencyConversion body = currencyExchangeProxy.retriveExchange(from, to);

		return new CurrencyConversion(body.getId(), from, to, quantity.multiply(body.getConversionMultiple()),
				body.getConversionMultiple(), body.getTotalCalculatedAmt(), body.getEnvironment());

	}
}
