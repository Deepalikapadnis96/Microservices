package com.microservice.currencyexchangeservice;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CircuitBreakerController {
	@GetMapping("/sample-api")
	// @Retry(name = "retrying-data", fallbackMethod = "hardcodeResponse")
	// @CircuitBreaker(name = "default", fallbackMethod = "hardcodeResponse")
	public String sampleApi() {
		log.info("inside the sample method");
		ResponseEntity<String> forEntity = new RestTemplate().getForEntity("http://localhost:8001/ome-dummy-url",
				String.class);
		return forEntity.getBody();

	}
	@GetMapping("/sample-api1")
	//@RateLimiter(name = "default")
	@Bulkhead(name="default")
	public String sampleApi1() {
		log.info("inside the sample1 method");

		return "rateLimiterRespose";

	}

	public String hardcodeResponse(Exception ex) {
		return "fallback-response";
	}
}
