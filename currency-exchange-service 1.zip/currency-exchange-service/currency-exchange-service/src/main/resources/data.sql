insert into currency_Exchange
(id,currency_from,currency_to,conversion_multiple,environment)
values(10001,'USD','INR',65,'');
insert into currency_Exchange
(id,currency_from,currency_to,conversion_multiple,environment)
values(10002,'EUR','INR',66,'');
insert into currency_Exchange
(id,currency_from,currency_to,conversion_multiple,environment)
values(10003,'INR','INR',67,'');
insert into currency_Exchange
(id,currency_from,currency_to,conversion_multiple,environment)
values(10004,'AUD','INR',68,'');